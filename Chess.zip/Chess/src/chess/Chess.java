/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chess;
import chess.gameParts.Chessboard;
import chess.gameParts.GamePlayer;
import java.io.InputStream;

/**
 *
 * @author shini
 */
public class Chess {

 
    GamePlayer playerWhite;
    GamePlayer playerBlack;
    Chessboard playSlate;
    
    //initialize board
     public Chess() {
    playerWhite = new GamePlayer("White", true);
    playerBlack = new GamePlayer("Black", false);
    playSlate = new Chessboard();
    
    
    //Adds all pieces
    playSlate.addPiece("Pawn", 0, 1, "White");
    playSlate.addPiece("Pawn", 1, 1, "White");
    playSlate.addPiece("Pawn", 2, 1, "White");
    playSlate.addPiece("Pawn", 3, 1, "White");
    playSlate.addPiece("Pawn", 4, 1, "White");
    playSlate.addPiece("Pawn", 5, 1, "White");
    playSlate.addPiece("Pawn", 6, 1, "White");
    playSlate.addPiece("Pawn", 7, 1, "White");
    playSlate.addPiece("Rook", 7, 0, "White");
    playSlate.addPiece("Rook", 0, 0, "White");
    playSlate.addPiece("Knight", 1, 0, "White");
    playSlate.addPiece("Knight", 6, 0, "White");
    playSlate.addPiece("Bishop", 2, 0, "White");
    playSlate.addPiece("Bishop", 5, 0, "White");
    playSlate.addPiece("King", 3, 0, "White");
    playSlate.addPiece("Queen", 4, 0, "White");
    
    
    playSlate.addPiece("Pawn", 0, 6, "Black");
    playSlate.addPiece("Pawn", 1, 6, "Black");
    playSlate.addPiece("Pawn", 2, 6, "Black");
    playSlate.addPiece("Pawn", 3, 6, "Black");
    playSlate.addPiece("Pawn", 4, 6, "Black");
    playSlate.addPiece("Pawn", 5, 6, "Black");
    playSlate.addPiece("Pawn", 6, 6, "Black");
    playSlate.addPiece("Pawn", 7, 6, "Black");
    playSlate.addPiece("Rook", 7, 7, "Black");
    playSlate.addPiece("Rook", 0, 7, "Black");
    playSlate.addPiece("Knight", 6, 7, "Black");
    playSlate.addPiece("Knight", 1, 7, "Black");
    playSlate.addPiece("Bishop", 5, 7, "Black");
    playSlate.addPiece("Bishop", 2, 7, "Black");
    playSlate.addPiece("King", 3, 7, "Black");
    playSlate.addPiece("Queen", 4, 7, "Black");
}
    
    //Some music : >
    public void phosphor() {
        
        InputStream phosphor;
        
    }
   
    
    public static void main(String[] args) {
         Chess letsGo = new Chess();
        
    }
}
