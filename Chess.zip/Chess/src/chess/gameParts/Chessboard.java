package chess.gameParts;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author shini
 */
public class Chessboard {
    
    
    public String whosTurn = "White";
    
    //checks if a panel is selected
    public boolean panelSelected = false;
    
    //Column of selected panel
    private int col;
    
    //Row of selected panel
    private int row;
    
    
    
    
    
    //components
    private ChessPiece[][] squares = new ChessPiece[8][8];
    ImageIcon icon = new ImageIcon();
    private ChessPiece placebo;
    
    
    //Board
    private JPanel board = new JPanel();
    JFrame boardFrame = new JFrame();
    
    
    
    
    //adds pieces to the board
    public void addPiece(String piecename, int x, int y, String ownerPlayer) {
        String pieceTitle = piecename;
        squares[y][x].setIcon(null);
        switch(pieceTitle){
            //No piece, might be needed for color?
            case "":
                icon = new ImageIcon("src\\transparent.jpg");
                squares[y][x] = new ChessPiece("", x, y, ownerPlayer);
                squares[y][x].setIcon(null);
                squares[y][x].setOwner(ownerPlayer);
                squares[y][x].addMouseListener(buttonHandler);
            break;
            
             //Pawns    
            case "Pawn":
                if (ownerPlayer.equals("White")) {
                    icon = new ImageIcon("src\\WhitePawn.png");
                  }
                else {
                     icon = new ImageIcon("src\\BlackPawn.png");
                 }
                squares[y][x].setIcon(icon);
                squares[y][x] = new ChessPiece(piecename,x, y, ownerPlayer);
                squares[y][x].addMouseListener(buttonHandler);
                squares[y][x].setOwner(ownerPlayer);
                break;
            
            
            //Knight
            case "Knight":
                if (ownerPlayer.equals("White")) {
                    icon = new ImageIcon("src\\WhiteKnight.png");  
                }
                else {
                     icon = new ImageIcon("src\\BlackKnight.png");
                 }
                squares[y][x].setIcon(icon);
                squares[y][x] = new ChessPiece(piecename, x, y, ownerPlayer);
                squares[y][x].addMouseListener(buttonHandler);
                squares[y][x].setOwner(ownerPlayer);
                break;
                
            //Rook
            case "Rook":
                if (ownerPlayer.equals("White")) {
                    icon = new ImageIcon("src\\WhiteRook.png");
                  }
                else {
                     icon = new ImageIcon("src\\BlackRook.png");
                 }
                squares[y][x].setIcon(icon);
                squares[y][x] = new ChessPiece(piecename, x, y, ownerPlayer);
                squares[y][x].addMouseListener(buttonHandler);
                squares[y][x].setOwner(ownerPlayer);
                break;
                
           
                
            //Bishops    
            case "Bishop":
                if (ownerPlayer.equals("White")) {
                    icon = new ImageIcon("src\\WhiteBishop.png");
                  }
                else {
                     icon = new ImageIcon("src\\BlackBishop.png");
                 }
                squares[y][x].setIcon(icon);
                squares[y][x] = new ChessPiece(piecename, x, y, ownerPlayer);
                squares[y][x].addMouseListener(buttonHandler);
                squares[y][x].setOwner(ownerPlayer);
                break;
             
                
            //Queen    
            case "Queen":
                if (ownerPlayer.equals("White")) {
                    icon = new ImageIcon("src\\WhiteQueen.png");
                  }
                else {
                     icon = new ImageIcon("src\\BlackQueen.png");
                 }
                squares[y][x].setIcon(icon);
                squares[y][x] = new ChessPiece(piecename, x, y, ownerPlayer);
                squares[y][x].addMouseListener(buttonHandler);
                squares[y][x].setOwner(ownerPlayer);
                break;
            
                
            //King
            case "King":
                if (ownerPlayer.equals("White")) {
                    icon = new ImageIcon("src\\WhiteKing.png");
                  }
                else {
                     icon = new ImageIcon("src\\BlackKing.png");
                 }
                squares[y][x].setIcon(icon);
                squares[y][x] = new ChessPiece(piecename, x, y, ownerPlayer);
                squares[y][x].addMouseListener(buttonHandler);
                squares[y][x].setOwner(ownerPlayer);
                break;
        }
    
    } 
    
    //Will make the color black for squares
    private Color colorGray = new Color(64, 64, 64);
    private Color colorLightGray = new Color(224, 224, 224);
    
    //Highlights when shaded
    private Color highlighter = Color.cyan;
    //keeps old color
    private Color originalColor;
    
    //Creates event handlers
    ButtonHandler buttonHandler = new ButtonHandler();
    
    
    
    
    public Chessboard() {
    board.setLayout(new GridLayout(8, 8, 1, 1));
    
    
    //creates board components
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
        squares[i][j] = new ChessPiece("King", i, j, "White");
        if ((i+j) % 2 != 0) {
        squares[i][j].setBackground(colorGray);
        }
        else {
        squares[i][j].setBackground(colorLightGray);
        }
        board.add(squares[i][j]);
        squares[i][j].addMouseListener(buttonHandler);
        }
    }
    
    //Size and Display window
    boardFrame.add(board);
    boardFrame.setSize(750, 750);
    boardFrame.setResizable(false);
    //This centers the window
    boardFrame.setLocationRelativeTo(null); 
    //makes the board visible
    boardFrame.setVisible(true);
    boardFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    
    
    
    
    
    //Mouse listener for each square
     private class ButtonHandler implements MouseListener {
    public void actionPerformed(ActionEvent e) {
    }
        //Processes clicks
        @Override
        public void mouseClicked(MouseEvent e) {
           ChessPiece source = (ChessPiece) (JButton) e.getComponent();
           
           
       
                  if (source.getType().equals("King")){
            source.setBackground(Color.green);
           }
           else {
            source.setBackground(Color.red);
           }
           
           //If no panel is selected, select that one.
           if (panelSelected == false) {
           
           }
           
           //If a panel is already selected, see if it can move there, and switch the player
           else {
               //processes the move
               
               
               
               
               
               //Changes the player after the move is processed
               if (whosTurn.equals("White")) {
               whosTurn = "Black";
               }
               else {
               whosTurn = "White";
               }
           
           }
           
           
           
        }

        @Override
        public void mousePressed(MouseEvent e) {
           ChessPiece source = (ChessPiece) (JButton) e.getComponent();
          
            
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          ChessPiece source = (ChessPiece) (JButton) e.getComponent();
         
        }
        
        
        
        
        
        //Changes the color of the piece when you hover it over, and then back hwen you leave
        @Override
        public void mouseEntered(MouseEvent e) {
          ChessPiece source = (ChessPiece) (JButton) e.getComponent();
             originalColor = source.getBackground();
             source.setBackground(Color.cyan);
        }

        @Override
        public void mouseExited(MouseEvent e) {
          ChessPiece source = (ChessPiece) (JButton) e.getComponent();
           source.setBackground(originalColor);
           
        }
    }


   
    
   
    
    
    
    public static void main(String[] args) {
    Chessboard test = new Chessboard();
    test.addPiece("King", 1, 1, "White");
    
     
    
    }
}
