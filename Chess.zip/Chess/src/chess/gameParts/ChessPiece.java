/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chess.gameParts;

/**
 *
 * @author shini
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.awt.Color;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 *
 * @author shini
 */


public class ChessPiece extends JButton {
    //Position
    int x = 0;
    int y = 0;
    
    
    boolean isSelected = false;

 
    
    //Determines who owns a piece
    String ownerPlayer = "White";
    //Will this work?
     String proGamerMove;
     
     //ImageIcon for the icon
     ImageIcon pic;
     
    
    //Piece type?
    String piece = "";
    
    public ChessPiece(String pieceType, int startX, int startY, String ownedBy) {
    x = startX;
    y = startY;
    ownerPlayer = ownedBy;
    piece = pieceType;
    proGamerMove = ownedBy;
    pic = null;
    setIcon(pic);
    
     switch(pieceType){
            //No piece, might be needed for color?
            case "":
                pic = null;
                setIcon(pic);
            break;
            
             //Pawns    
            case "Pawn":
                if (ownerPlayer.equals("White")) {
                    pic = new ImageIcon("src\\WhitePawn.png");
                  }
                else {
                     pic = new ImageIcon("src\\BlackPawn.png");
                 }
                pic = null;
                setIcon(pic);
                break;
            
            
            //Knight
            case "Knight":
                if (ownerPlayer.equals("White")) {
                    pic = new ImageIcon("src\\WhiteKnight.png");  
                }
                else {
                     pic = new ImageIcon("src\\BlackKnight.png");
                 }
                pic = null;
                setIcon(pic);
                break;
                
            //Rook
            case "Rook":
                if (ownerPlayer.equals("White")) {
                    pic = new ImageIcon("src\\WhiteRook.png");
                  }
                else {
                     pic = new ImageIcon("src\\BlackRook.png");
                 }
                pic = null;
                setIcon(pic);
                break;
                
           
                
            //Bishops    
            case "Bishop":
                if (ownerPlayer.equals("White")) {
                    pic = new ImageIcon("src\\WhiteBishop.png");
                  }
                else {
                     pic = new ImageIcon("src\\BlackBishop.png");
                 }
                pic = null;
                setIcon(pic);
                break;
             
                
            //Queen    
            case "Queen":
                if (ownerPlayer.equals("White")) {
                    pic = new ImageIcon("src\\WhiteQueen.png");
                  }
                else {
                     pic = new ImageIcon("src\\BlackQueen.png");
                 }
                pic = null;
                setIcon(pic);
                break;
            
                
            //King
            case "King":
                if (ownerPlayer.equals("White")) {
                    pic = new ImageIcon("src\\WhiteKing.png");
                  }
                else {
                     pic = new ImageIcon("src\\BlackKing.png");
                 }
                pic = null;
                setIcon(pic);
                break;
        }
    
    
    
    
    }
    
    public void setOwner(String newOwner) {
    ownerPlayer = newOwner;
    }
    
  //Gets the x position
    public int getSideX() {
    return x;
    }
    
    public void isClicked(boolean status) {
    
    }
    
    
    //Gets y position
    public int getUpY() {
    return y;
    }
    
    public Color getBackground() {
        ownerPlayer = proGamerMove;
    return super.getBackground();
    }
    
    public void setBackground(Color c) {
    super.setBackground(c);
    }
    
    public void setIcon(ImageIcon icon) {
    super.setIcon(icon);
    }
    
    public String getColorOwner() {
    return ownerPlayer;
    }
    
    public String getType() {
    return piece;
    }
    
    
    //Determines if a move is valid for each piece
    private void isValidMove(int row, int col) {
    switch(this.getType()) {
    case("Pawn"):
        
        //White Pawn moves
        
        //Black Pawn Moves
        
        
        break;
        
    case("Bishop"):
        
        break;  
    
    case("Knight"):
        
        break;
        
    case("Rook"):
        
        break;
    
    case("Queen"):
        
        break;
        
    case("King"):
        
        break;
    }
    }
    
    
    
    
    
    
    
    public static void main(String[] args) {
    System.out.print("WTF");
    }
}

