package chess.gameParts;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author shini
 */
public class GamePlayer {
    boolean hasWon;
   boolean hasLost;
   boolean isYourTurn;
   String nameColor;
   
    public GamePlayer(String name, boolean isTurn) {
    nameColor = name;
    isYourTurn = isTurn;
    hasLost = false;
    hasWon = false;
    }
   
    
}
